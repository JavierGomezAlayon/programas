/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @file producto_digitos.cc
  * @autor alu0101562445@ull.edu.es
  * @fecha 16 nov 2022
  * @resumen El programa reads several numbers, and for each one prints the product of its digits, and the product of the digits of the latest product, etcetera, until the resulting product has just one digit.
  */

#include <iostream>



void ProductoDeDigitos(const int numero) {
  SeparadorDeDigitos (numero)
}

int main() {
  while (std::cin = numero) {
    productoDeDigitos(numero) {
  }
  
  }
}
